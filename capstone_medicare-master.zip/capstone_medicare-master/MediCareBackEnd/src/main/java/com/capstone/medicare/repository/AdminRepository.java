package com.capstone.medicare.repository;



import org.springframework.data.jpa.repository.JpaRepository;

import com.capstone.medicare.entity.Admin;

public interface AdminRepository extends JpaRepository<Admin, Integer>{
	
     
	
}
